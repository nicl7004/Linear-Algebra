function a = rectpos
%
% draw a rectangle
%
x = [0 1 1 0];
y = [0 0 1 1];
z = [0 0 0 0];
h = [1 1 1 1];
a = [x; y; z; h];

hold on
%
end